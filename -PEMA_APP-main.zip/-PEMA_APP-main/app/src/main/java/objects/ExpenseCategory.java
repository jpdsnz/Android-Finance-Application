package objects;

public enum ExpenseCategory {
    None,
    Needs,
    Wants,
    Saves
}
